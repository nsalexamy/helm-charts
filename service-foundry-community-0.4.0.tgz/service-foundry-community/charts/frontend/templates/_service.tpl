{{- define "frontend.service" }}

apiVersion: v1
kind: Service
metadata:
  name: {{ default (include "frontend.fullname" .) .serviceName }}
  labels:
    {{- include "frontend.labels" . | nindent 4 }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      targetPort: http
      protocol: TCP
      name: http
  selector:
    {{- include "frontend.selectorLabels" . | nindent 4 }}

{{- end }}